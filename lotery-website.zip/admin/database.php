<?php
//Create database connection

$conn = mysqli_connect("localhost","root","","lottery_baby");
//$conn = mysqli_connect("localhost","lotteryb_rot","]ako7AeS_[(r","lotteryb_phpsite");
if (!$conn) {

die("Connection error: " . mysqli_connect_error());

}
?>